//
//  CoreDataVC.swift
//  CoreDataApp
//
//  Created by Apptist Inc. on 2022-11-24.
//

import UIKit
import CoreData

class CoreDataVC: UITableViewController {
    
    //MARK: - Core Data Objects
    
    var people: [NSManagedObject] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

    }
    
    override func viewWillAppear(_ animated: Bool) {
        //MARK: - Fetch the saved items from Core Data
        
        //MARK: - Reference to App Delegate
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            ///If this doesn't work we will return, hence guard
            return
        }
        
        //MARK: - Get container from app delegate
        let managedContext = appDelegate.persistentContainer.viewContext
        
        //MARK: - Fetch request, Person object from container
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        do {
            //MARK: - Perform a search inside the container
            people = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            //MARK: - If the fetch did not work
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return people.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //MARK: - Populate table with cells that have Person's name
        
        //MARK: - Get the person at each row
        let person = people[indexPath.row]
        
        //Set the cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        //Set the cell's text to name
        cell.textLabel?.text = person.value(forKey: "name") as? String

        return cell
    }
    
    @IBAction func addName(_ sender: UIBarButtonItem) {
        //MARK: - When we add it will prompt us to enter a name for a Person object
        
        //MARK: - Action to create an alert to add a new name
        let alert = UIAlertController(title: "New Name", message: "Add a new name", preferredStyle: .alert)
        
        //MARK: - Save action
        let saveAction = UIAlertAction(title: "Save", style: .default) { action in
            
            //MARK: - Run an action after alert is created
            
            //MARK: - Create a text field for our alert to enter person's name
            guard let textField = alert.textFields?.first,
                  let nameToSave = textField.text else {
                //MARK: - Save text entered as "nameToSave"
                    return
            }
            
            //MARK: - Save to Core Data and reload table
            self.save(name: nameToSave)
            self.tableView.reloadData()
            
        }
        
        //MARK: - Cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alert.addTextField() //Add all text fields
        alert.addAction(saveAction) //Add save button
        alert.addAction(cancelAction) //Add cancel button
        
        present(alert, animated: true) //Present alert
    }
 
    
    func save(name: String) {
        //MARK: - Save name to Core Data container
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Person", in: managedContext)!
        
        let person = NSManagedObject(entity: entity, insertInto: managedContext)
        person.setValue(name, forKey: "name")
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        do {
            try managedContext.save()
            people.append(person)
        } catch let error as NSError {
            
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    
  
}
