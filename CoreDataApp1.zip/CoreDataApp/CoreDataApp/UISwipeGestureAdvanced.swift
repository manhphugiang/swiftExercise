//
//  UISwipeGestureAdvanced.swift
//  CoreDataApp
//
//  Created by Apptist Inc. on 2022-11-24.
//

import UIKit

class UISwipeGestureAdvanced: UISwipeGestureRecognizer {

}
