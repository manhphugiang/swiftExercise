//
//  ViewController.swift
//  CoreDataApp
//
//  Created by Apptist Inc. on 2022-11-24.
//

import UIKit

class ViewController: UIViewController {
    
    //Create tap gesture programatically
    var tapGesture: UITapGestureRecognizer?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
        //Init tap gesture
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap(_:)))
        self.view.addGestureRecognizer(tapGesture!)
        tapGesture?.numberOfTapsRequired = 1
    }
    
    @objc func tap(_ gestureRecognizer: UITapGestureRecognizer) {
        print("I was tapped")
    }
    
    @IBAction func tapped(_ gestureRecognizer: UITapGestureRecognizer) {
        
        gestureRecognizer.numberOfTapsRequired = 2
        
        if gestureRecognizer.location(in: view) == CGPoint(x: 500, y: 500) {
            //I tapped inside the view
        }
        
    }

    @IBAction func swiped(_ gestureRecognizer: UISwipeGestureRecognizer) {
        
        if gestureRecognizer.direction == .right {
            navigationController?.pushViewController(SecondViewController(), animated: true)

        }
        
        if gestureRecognizer.direction == .left {
            navigationController?.pushViewController(ThirdViewController(), animated: true)
        }
        
        
    }
    
    @IBAction func panned(_ gestureRecognizer: UIPanGestureRecognizer) {
        
        gestureRecognizer.maximumNumberOfTouches = 2
        
    }
    
    //@IBAction func pinched(_ gestureRecognizer: UI)

}

